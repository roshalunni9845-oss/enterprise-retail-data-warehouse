-- 01_schema.sql
-- Star schema for the Enterprise Retail Data Warehouse (PostgreSQL)
-- Layers: staging (raw) -> clean -> star schema (fact + dimensions)

-- Staging: raw data exactly as loaded (541,909 rows)
CREATE TABLE stg_online_retail (
    invoice_no    VARCHAR(20),
    stock_code    VARCHAR(50),
    description   TEXT,
    quantity      INTEGER,
    invoice_date  TIMESTAMP,
    unit_price    NUMERIC(10,2),
    customer_id   INTEGER,
    country       VARCHAR(100)
);

-- Clean: staging data after cleaning rules (530,100 rows)
CREATE TABLE clean_online_retail (
    invoice_no    VARCHAR(20),
    stock_code    VARCHAR(50),
    description   TEXT,
    quantity      INTEGER,
    invoice_date  TIMESTAMP,
    unit_price    NUMERIC(10,2),
    customer_id   INTEGER,
    country       VARCHAR(100)
);

-- Dimensions
CREATE TABLE dim_country (
    country_key   INTEGER PRIMARY KEY,
    country_name  VARCHAR(100)
);

CREATE TABLE dim_customer (
    customer_key  INTEGER PRIMARY KEY,
    customer_id   INTEGER,
    country       VARCHAR(100)
);

CREATE TABLE dim_date (
    date_key      INTEGER PRIMARY KEY,   -- format YYYYMMDD
    full_date     DATE,
    year          INTEGER,
    quarter       INTEGER,
    month         INTEGER,
    month_name    VARCHAR(20),
    day           INTEGER
);

CREATE TABLE dim_product (
    product_key   INTEGER PRIMARY KEY,
    stock_code    VARCHAR(50),
    description   TEXT
);

-- Fact table (grain: one invoice line)
CREATE TABLE fact_sales (
    sales_key     INTEGER PRIMARY KEY,
    invoice_no    VARCHAR(20),
    product_key   INTEGER REFERENCES dim_product(product_key),
    customer_key  INTEGER REFERENCES dim_customer(customer_key),
    date_key      INTEGER REFERENCES dim_date(date_key),
    country_key   INTEGER REFERENCES dim_country(country_key),
    quantity      INTEGER,
    unit_price    NUMERIC(10,2),
    total_sales   NUMERIC(12,2)          -- quantity * unit_price
);
