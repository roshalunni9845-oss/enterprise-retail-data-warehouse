-- 02_cleaning_rules.sql
-- Cleaning rules applied from staging to clean.
-- Result: 541,909 staging rows -> 530,100 clean rows (11,809 removed).
--
-- Rules (rows are removed if ANY of these is true):
--   1. Cancelled invoices (invoice_no starts with 'C')   -> 9,288 rows in staging
--   2. Zero or negative quantity                         -> 10,624 rows
--   3. Zero or negative unit price                       -> 2,521 rows
--   4. Missing or blank product description              -> 1,454 rows
-- (Some rows match more than one rule, so the counts overlap.)

INSERT INTO clean_online_retail
SELECT *
FROM stg_online_retail
WHERE invoice_no NOT LIKE 'C%'
  AND quantity > 0
  AND unit_price > 0
  AND description IS NOT NULL
  AND TRIM(description) <> '';

-- Rows with a missing customer_id are KEPT and mapped to an
-- "unknown customer" row (customer_key = 0) in dim_customer.
