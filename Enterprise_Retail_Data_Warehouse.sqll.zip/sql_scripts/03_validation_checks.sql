-- 03_validation_checks.sql
-- Data validation checks for the warehouse. Run after loading.
-- Expected results are shown in the comments.

-- 1. Row reconciliation: staging vs clean vs fact
SELECT 'staging' AS layer, COUNT(*) AS row_count FROM stg_online_retail   -- 541,909
UNION ALL
SELECT 'clean',            COUNT(*) FROM clean_online_retail              -- 530,100
UNION ALL
SELECT 'fact_sales',       COUNT(*) FROM fact_sales;                      -- 530,100

-- 2. Rows removed during cleaning
SELECT
    (SELECT COUNT(*) FROM stg_online_retail)
  - (SELECT COUNT(*) FROM clean_online_retail) AS rows_removed;           -- 11,809

-- 3. Clean layer should have no invalid values (all should be 0)
SELECT
    COUNT(*) FILTER (WHERE invoice_no LIKE 'C%')                      AS cancelled_invoices,
    COUNT(*) FILTER (WHERE quantity <= 0)                             AS bad_quantity,
    COUNT(*) FILTER (WHERE unit_price <= 0)                           AS bad_price,
    COUNT(*) FILTER (WHERE description IS NULL OR TRIM(description) = '') AS missing_description
FROM clean_online_retail;

-- 4. Missing customer IDs (kept, mapped to customer_key = 0)
SELECT COUNT(*) AS rows_without_customer_id                            -- 132,220
FROM clean_online_retail
WHERE customer_id IS NULL;

-- 5. Duplicate rows still present in the clean data
--    (extra copies beyond the first of each identical row)
SELECT COALESCE(SUM(copies - 1), 0) AS extra_duplicate_rows            -- 5,226
FROM (
    SELECT COUNT(*) AS copies
    FROM clean_online_retail
    GROUP BY invoice_no, stock_code, description, quantity,
             invoice_date, unit_price, customer_id, country
    HAVING COUNT(*) > 1
) d;

-- 6. Referential integrity: fact rows with no matching dimension (all should be 0)
SELECT
    COUNT(*) FILTER (WHERE p.product_key  IS NULL) AS orphan_products,
    COUNT(*) FILTER (WHERE c.customer_key IS NULL) AS orphan_customers,
    COUNT(*) FILTER (WHERE d.date_key     IS NULL) AS orphan_dates,
    COUNT(*) FILTER (WHERE k.country_key  IS NULL) AS orphan_countries
FROM fact_sales f
LEFT JOIN dim_product  p ON f.product_key  = p.product_key
LEFT JOIN dim_customer c ON f.customer_key = c.customer_key
LEFT JOIN dim_date     d ON f.date_key     = d.date_key
LEFT JOIN dim_country  k ON f.country_key  = k.country_key;

-- 7. total_sales should equal quantity * unit_price (should be 0)
SELECT COUNT(*) AS mismatched_totals
FROM fact_sales
WHERE ABS(total_sales - quantity * unit_price) > 0.01;

-- 8. Headline numbers for the full data period (1 Dec 2010 - 9 Dec 2011)
SELECT
    ROUND(SUM(total_sales), 2)       AS total_sales,      -- 10,666,684.54
    COUNT(DISTINCT invoice_no)       AS total_orders,     -- 19,960
    SUM(quantity)                    AS units_sold,       -- 5,588,372
    ROUND(SUM(total_sales) / COUNT(DISTINCT invoice_no), 2) AS avg_order_value  -- 534.40
FROM fact_sales;
